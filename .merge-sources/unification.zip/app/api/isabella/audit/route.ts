import { ledger } from "@/lib/isabella/audit"

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const limit = Number(searchParams.get("limit") ?? 50)
  return Response.json({
    chainValid: ledger.verifyChain(),
    lastHash: ledger.lastHash,
    events: ledger.list(Number.isFinite(limit) ? limit : 50),
  })
}
